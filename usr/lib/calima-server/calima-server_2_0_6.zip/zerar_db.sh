#!/bin/bash
# Descricao: Script de de controle do calima server
# Autor: Fabiano Henrique
# Data: 09/01/2020

source /usr/lib/calima-server/funcoes.sh

(

  echo "10" ; 
  echo "# Parando o servidor..."
  /usr/bin/docker stop tomcat 
  echo "20" ; 
  echo "# Removendo o tomcat..."
  /usr/bin/docker rm tomcat
  echo "50" ; 
  echo "# Matando conexões com banco..."
  /usr/bin/docker exec -it postgres psql -U postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'calima';"
  echo "70" ; 
  echo "# Apagando banco..."
  /usr/bin/docker exec -t postgres sh -c "psql -U postgres -c 'drop database calima;'"
  echo "90" ; 
  echo "# Criando banco zerado..."
  /usr/bin/docker exec -t postgres sh -c "psql -U postgres -c 'create database calima;'"]
  echo "100" ; 
  echo "# Pode efetuar a restauração agora.."
) |

    zenity --progress --auto-close --no-cancel \
    --height="100" --width="350" \
    --window-icon=/usr/lib/calima-server/icon.png \
    --class=CalimaServer \
    --title="Calima Server" \
    --text="Zerando DB, aguarde..." \
    --percentage=0


showNotification "Restauração do banco de dados concluída!"

notify-send -t 3000 "Facilitador Linux" "Banco zerado, já pode fazer a restauração novamente..."

exec ./calima-server.sh

